import os
import sys
import shutil
import requests
import json
import time
import readline  # For command history and arrow key support
from datetime import datetime
import re

# Configuration
GEMINI_API_KEY = "AIzaSyAjhwfAWpWLrrtOIIit-D7WX0bWsq4Nkkg"  # Replace with your free-tier API key
API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
MAX_HISTORY = 50  # Max number of commands to store in history
DEFAULT_STORAGE_PATH = "/sdcard"  # Default path for Android storage in Termux

# Initialize command history
history_file = os.path.expanduser("~/.gemini_terminal_history")
if os.path.exists(history_file):
    readline.read_history_file(history_file)

readline.set_history_length(MAX_HISTORY)

def save_history():
    """Save command history to file."""
    try:
        readline.write_history_file(history_file)
    except Exception as e:
        print(f"[⚠️] Failed to save history: {e}")

def get_gemini_response(prompt):
    """Fetch response from Gemini API."""
    headers = {"Content-Type": "application/json"}
    params = {"key": GEMINI_API_KEY}
    data = {
        "contents": [
            {
                "role": "user",
                "parts": [{"text": prompt}]
            }
        ],
        "generationConfig": {
            "temperature": 0.7,
            "topP": 0.95,
            "maxOutputTokens": 1024
        }
    }

    try:
        response = requests.post(API_ENDPOINT, headers=headers, params=params, json=data)
        response.raise_for_status()
        res_json = response.json()
        
        if "candidates" in res_json and res_json["candidates"]:
            return res_json["candidates"][0]["content"]["parts"][0]["text"]
        else:
            return "[❌] Error: No valid response from Gemini API."
    except requests.exceptions.RequestException as e:
        return f"[❌] Network Error: {str(e)}"
    except Exception as e:
        return f"[❌] Error: {str(e)}\nRaw response: {response.text}"

def loading_animation():
    """Display a simple loading animation."""
    frames = ["■□□□□", "■■□□□", "■■■□□", "■■■■□", "■■■■■"]
    for _ in range(2):  # Run animation for 2 cycles
        for frame in frames:
            print(f"\rThinking... {frame}", end="", flush=True)
            time.sleep(0.1)
    print("\r" + " " * 20, end="\r", flush=True)  # Clear line

def print_welcome():
    """Print welcome message with styling."""
    print("\033[1;34m=== AI SHELL ===\033[0m")
    print("Powered by Gemini 1.5 Flash (Free Tier)")
    print("Type \033[1mhelp\033[0m for commands, \033[1mclear\033[0m to clear screen, or \033[1mexit\033[0m to quit.")
    print("Use arrow keys for command history.\n")

def print_help():
    """Display help message."""
    return """
\033[1mAvailable Commands:\033[0m
  help                    - Show this help message
  clear                   - Clear the terminal screen
  exit                   - Exit the terminal
  create file <name> [in <path>] [with <content>] - Create a file (e.g., create file test.py in /sdcard with print('Hello'))
  create folder <name> [in <path>] - Create a folder (e.g., create folder mydir in /sdcard)
  delete file <name> [in <path>] - Delete a file (e.g., delete file test.txt in /sdcard)
  delete folder <name> [in <path>] - Delete a folder (e.g., delete folder mydir in /sdcard)
  <query>                - Ask Gemini AI anything (e.g., 'Write a Python script')
"""

def validate_path(path):
    """Validate if the path is accessible and safe."""
    try:
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.exists(os.path.dirname(path)):
            return False, f"Parent directory does not exist: {os.path.dirname(path)}"
        return True, path
    except Exception as e:
        return False, f"Invalid path: {str(e)}"

def create_file(file_name, path=DEFAULT_STORAGE_PATH, content=""):
    """Create a file with optional content."""
    is_valid, full_path = validate_path(os.path.join(path, file_name))
    if not is_valid:
        return f"[❌] {full_path}"
    
    try:
        with open(full_path, "w") as f:
            f.write(content)
        return f"[✔] File created: {full_path}"
    except Exception as e:
        return f"[❌] Failed to create file: {str(e)}"

def create_folder(folder_name, path=DEFAULT_STORAGE_PATH):
    """Create a folder."""
    is_valid, full_path = validate_path(os.path.join(path, folder_name))
    if not is_valid:
        return f"[❌] {full_path}"
    
    try:
        os.makedirs(full_path, exist_ok=True)
        return f"[✔] Folder created: {full_path}"
    except Exception as e:
        return f"[❌] Failed to create folder: {str(e)}"

def delete_file(file_name, path=DEFAULT_STORAGE_PATH):
    """Delete a file with confirmation."""
    is_valid, full_path = validate_path(os.path.join(path, file_name))
    if not is_valid:
        return f"[❌] {full_path}"
    
    if not os.path.isfile(full_path):
        return f"[❌] File does not exist: {full_path}"
    
    confirm = input(f"\033[33mConfirm deletion of {full_path}? [y/N] -> \033[0m").strip().lower()
    if confirm != "y":
        return "[✩] Deletion canceled."
    
    try:
        os.remove(full_path)
        return f"[✔] File deleted: {full_path}"
    except Exception as e:
        return f"[❌] Failed to delete file: {str(e)}"

def delete_folder(folder_name, path=DEFAULT_STORAGE_PATH):
    """Delete a folder with confirmation."""
    is_valid, full_path = validate_path(os.path.join(path, folder_name))
    if not is_valid:
        return f"[❌] {full_path}"
    
    if not os.path.isdir(full_path):
        return f"[❌] Folder does not exist: {full_path}"
    
    confirm = input(f"\033[33mConfirm deletion of {full_path} and its contents? [y/N] -> \033[0m").strip().lower()
    if confirm != "y":
        return "[✩] Deletion canceled."
    
    try:
        shutil.rmtree(full_path)
        return f"[✔] Folder deleted: {full_path}"
    except Exception as e:
        return f"[❌] Failed to delete folder: {str(e)}"

def parse_command(prompt):
    """Parse user input for file/folder commands."""
    prompt = prompt.strip().lower()
    
    # Patterns for commands
    create_file_pattern = r'^create file (\w+\.\w+)(?: in ([^\s]+))?(?: with (.+))?$'
    create_folder_pattern = r'^create folder (\w+)(?: in ([^\s]+))?$'
    delete_file_pattern = r'^delete file (\w+\.\w+)(?: in ([^\s]+))?$'
    delete_folder_pattern = r'^delete folder (\w+)(?: in ([^\s]+))?$'
    
    # Check for create file
    match = re.match(create_file_pattern, prompt)
    if match:
        file_name, path, content = match.groups()
        path = path or DEFAULT_STORAGE_PATH
        content = content or ""
        return create_file(file_name, path, content)
    
    # Check for create folder
    match = re.match(create_folder_pattern, prompt)
    if match:
        folder_name, path = match.groups()
        path = path or DEFAULT_STORAGE_PATH
        return create_folder(folder_name, path)
    
    # Check for delete file
    match = re.match(delete_file_pattern, prompt)
    if match:
        file_name, path = match.groups()
        path = path or DEFAULT_STORAGE_PATH
        return delete_file(file_name, path)
    
    # Check for delete folder
    match = re.match(delete_folder_pattern, prompt)
    if match:
        folder_name, path = match.groups()
        path = path or DEFAULT_STORAGE_PATH
        return delete_folder(folder_name, path)
    
    # If no match, return None to indicate it's a Gemini query
    return None

def main():
    """Main terminal loop."""
    print_welcome()
    
    while True:
        try:
            prompt = input("\033[1;32mYou > \033[0m").strip()
            
            if not prompt:
                continue
                
            # Save to history
            readline.add_history(prompt)
            save_history()
            
            # Handle built-in commands
            if prompt.lower() == "exit":
                print("\033[1;33mGoodbye! ✦\033[0m")
                break
            elif prompt.lower() == "clear":
                os.system("clear" if os.name != "nt" else "cls")
                print_welcome()
                continue
            elif prompt.lower() == "help":
                print(print_help())
                continue
                
            # Parse for file/folder commands
            result = parse_command(prompt)
            if result:
                timestamp = datetime.now().strftime("%H:%M:%S")
                print(f"\033[1;34mBoss [{timestamp}] > \033[0m{result}\n")
                continue
                
            # Show loading animation for Gemini queries
            loading_animation()
            
            # Get response from Gemini
            response = get_gemini_response(prompt)
            
            # Print response with timestamp
            timestamp = datetime.now().strftime("%H:%M:%S")
            print(f"\033[1;34mBoss [{timestamp}] > \033[0m{response}\n")
            
        except KeyboardInterrupt:
            print("\n\033[1;33m[⚠️] Ctrl+C detected. Type 'exit' to quit.\033[0m")
        except Exception as e:
            print(f"\033[1;31m[❌] Unexpected error: {str(e)}\033[0m")

if __name__ == "__main__":
    main()
